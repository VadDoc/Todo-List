import React, {useReducer} from "react";
import './App.css';
import {Todolist} from './Todolist';
import {v1} from 'uuid';
import {AddTaskAC, changeStatusAC, RemoveTaskAC, TaskReducer} from "./reducers/TaskReducer";
import {filterReducer, setFilterAC} from "./reducers/FilterReducer";

export type FilterValuesType = "all" | "active" | "completed";

function App() {

    let [tasks, dispatchTasks] = useReducer(TaskReducer, [
        {id: v1(), title: "HTML&CSS", isDone: true},
        {id: v1(), title: "JS", isDone: true},
        {id: v1(), title: "ReactJS", isDone: false},
        {id: v1(), title: "Rest API", isDone: false},
        {id: v1(), title: "GraphQL", isDone: false},
    ]);
    let [filter, dispatchFilter] = useReducer(filterReducer, "all");

    function removeTask(id: string) {
        dispatchTasks(RemoveTaskAC(id));
    }

    function addTask(title: string) {
        dispatchTasks(AddTaskAC(title));
    }

    function changeStatus(taskId: string, isDone: boolean) {
        dispatchTasks(changeStatusAC(taskId, isDone))
    }


    let tasksForTodolist = tasks;

    if (filter === "active") {
        tasksForTodolist = tasks.filter(t => !t.isDone);
    }
    if (filter === "completed") {
        tasksForTodolist = tasks.filter(t => t.isDone);
    }

    function changeFilter(value: FilterValuesType) {
        dispatchFilter(setFilterAC(value))
    }


    return (
        <div className="App">
            <Todolist title="What to learn"
                      tasks={tasksForTodolist}
                      removeTask={removeTask}
                      changeFilter={changeFilter}
                      addTask={addTask}
                      changeTaskStatus={changeStatus}
                      filter={filter}
            />
        </div>
    );
}

export default App;
